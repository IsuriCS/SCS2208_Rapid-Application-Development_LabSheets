function areaOfCircle( r ){
    alert("Area of Circle with radious "+ r +" units: "+ 4 / 3 * 22 / 7 * r ^ 3)
}

function perimeterOfCircle( r ){
    alert("Perimeter of Circle with radious "+ r +" units : "+ 22 / 7 * r ^ 2)
}

function volumeOfCube( l ){
    alert ("Volume of Cube with "+l+"units length of a side : "+ l ^ 3)
}

function message (){
    alert("Hello , Welcome to our paradise .")
}